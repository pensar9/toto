# Android Animation Interpolator
Proof of concept
