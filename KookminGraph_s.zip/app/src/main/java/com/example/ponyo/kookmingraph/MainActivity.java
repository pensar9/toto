package com.example.ponyo.kookmingraph;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.ChangeBounds;
import android.transition.TransitionManager;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnticipateOvershootInterpolator;
import android.widget.Button;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {
    private Context mContext;
    private Activity mActivity;

    private static final String TAG = MainActivity.class.getSimpleName();

    private RelativeLayout mCLayout;
    private Button mButton;
    private View mViewBox;

    private boolean isBig = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get the application context
        mContext = getApplicationContext();
        mActivity = MainActivity.this;

        // Get the widget reference from XML layout
        mCLayout = (RelativeLayout) findViewById(R.id.coordinator_layout);
        mButton = (Button) findViewById(R.id.btn);
        mViewBox = (View) findViewById(R.id.view_box);

       // mViewBox.getLayoutParams().width = 400;
       // mViewBox.getLayoutParams().height = 100;

        // Set a click listener for button
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*
                    ChangeBounds
                        This transition captures the layout bounds of target views before and after
                        the scene change and animates those changes during the transition.
                */

                // Initialize a new ChangeBounds transition instance
                ChangeBounds changeBounds = new ChangeBounds();

                // Set the transition start delay
                changeBounds.setStartDelay(300);

                // Set the transition interpolator
                changeBounds.setInterpolator(new AnticipateOvershootInterpolator());

                // Specify the transition duration
                changeBounds.setDuration(1000);

                // Begin the delayed transition
                TransitionManager.beginDelayedTransition(mCLayout,changeBounds);

                // Toggle the button size
                toggleSize(mViewBox);
            }
        });
    }

    /**
     * This method converts device specific pixels to density independent pixels.
     *
     * @param px A value in px (pixels) unit. Which we need to convert into db
     * @param context Context to get resources and device specific display metrics
     * @return A float value to represent dp equivalent to px value
     */
    public static float convertPixelsToDp(float px, Context context){
        return px / ((float) context.getResources().getDisplayMetrics().densityDpi / DisplayMetrics.DENSITY_DEFAULT);
    }

    public static float convertDpToPixel(float dp, Context context){
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float px = dp * ((float)metrics.densityDpi / DisplayMetrics.DENSITY_DEFAULT);
        return px;
    }

    // Custom method to toggle view size
    protected void toggleSize(View v){
        ViewGroup.LayoutParams params = v.getLayoutParams();
        if(isBig){
            //params.width = 400;
            //params.height = 100;

            params.width = (int)convertDpToPixel(20, this);
            params.height = (int)convertDpToPixel(20, this);

            isBig = false;

        }else {
            //params.width = ViewGroup.LayoutParams.MATCH_PARENT;
           // params.height = ViewGroup.LayoutParams.MATCH_PARENT;
            params.width = (int)convertDpToPixel(200, this);
            params.height = (int)convertDpToPixel(20, this);
            //params.width = 800;
            //params.height = 100;
            isBig = true;
        }
        v.setLayoutParams(params);
    }
}
